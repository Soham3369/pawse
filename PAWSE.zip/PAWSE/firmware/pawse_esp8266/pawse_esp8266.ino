/*
  PAWSE smart collar firmware  -  NodeMCU ESP8266 (ESP-12E)
  Sensors : NEO-6M GPS (SoftwareSerial), MPU6050 IMU (I2C), status LED
  Device  : sensi69
  Sends JSON telemetry to Flask:  POST  http://<server-ip>:5000/api/telemetry
  Libraries (Arduino Library Manager): TinyGPSPlus (Mikal Hart), MPU6050_tockn (tockn)
  Board   : "NodeMCU 1.0 (ESP-12E Module)"   Serial monitor: 115200 baud

  Wiring
    MPU6050 VCC->3V3  GND->GND  SDA->D2(GPIO4)  SCL->D1(GPIO5)
    NEO-6M  GND->GND  TX->D5(GPIO14)  RX->D6(GPIO12)  VCC->3V3 (see README before using 5V)
    LED     D7(GPIO13) -> 220 ohm -> LED anode ; LED cathode -> GND

  LED meaning
    fast blink (5 Hz)            : WiFi connecting / disconnected
    slow heartbeat (1 blink/2 s) : WiFi OK and GPS fix valid
    double blink every ~1.5 s    : WiFi OK but GPS UNAVAILABLE (no fix)
    one short flash              : telemetry sent successfully
    three rapid flashes          : server/HTTP error (will retry)
*/
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>
#include <Wire.h>
#include <MPU6050_tockn.h>

// ======================= USER SETTINGS =======================
const char* WIFI_SSID   = "YOUR_WIFI_NAME";
const char* WIFI_PASS   = "YOUR_WIFI_PASSWORD";
const char* SERVER_URL  = "http://192.168.1.50:5000/api/telemetry";   // PC running Flask (same WiFi). Use ipconfig/ifconfig.
const char* DEVICE_ID   = "sensi69";
const char* DEVICE_KEY  = "sensi69-change-this-device-key";            // must equal PAWSE_SENSI69_KEY on the server
const unsigned long SEND_INTERVAL_MS = 5000;                           // telemetry period
// =============================================================

// Pins (NodeMCU labels)
const uint8_t PIN_SDA = D2;      // GPIO4
const uint8_t PIN_SCL = D1;      // GPIO5
const uint8_t PIN_GPS_RX = D5;   // GPIO14  <- NEO-6M TX
const uint8_t PIN_GPS_TX = D6;   // GPIO12  -> NEO-6M RX
const uint8_t PIN_LED = D7;      // GPIO13

SoftwareSerial gpsSerial(PIN_GPS_RX, PIN_GPS_TX);
TinyGPSPlus gps;
MPU6050 mpu(Wire);

const float G_MS2 = 9.80665f;
unsigned long lastSend = 0, lastWifiTry = 0, lastDebug = 0, gpsCharsSeen = 0;
float dynSum = 0; uint32_t dynCount = 0;               // mean dynamic acceleration since last send
float ax = 0, ay = 0, az = 9.81f, gx = 0, gy = 0, gz = 0;
bool imuOk = false;

// ---- LED state machine (non-blocking) ----
unsigned long flashUntil = 0; uint8_t flashCount = 0; unsigned long flashStart = 0;
void flashShort()  { flashCount = 1; flashStart = millis(); }
void flashError()  { flashCount = 3; flashStart = millis(); }
bool wifiUp() { return WiFi.status() == WL_CONNECTED; }
bool gpsValid() { return gps.location.isValid() && gps.location.age() < 3000 && gps.satellites.isValid() && gps.satellites.value() >= 3; }

void updateLed() {
  unsigned long now = millis();
  if (flashCount > 0) {                                  // event flashes override the base pattern
    unsigned long t = now - flashStart;
    unsigned long period = (flashCount == 1) ? 60 : 120; // short flash / rapid triple
    uint8_t idx = t / period;
    if (idx >= flashCount * 2) { flashCount = 0; }
    else { digitalWrite(PIN_LED, (idx % 2 == 0) ? HIGH : LOW); return; }
  }
  bool on;
  if (!wifiUp())          on = (now % 200) < 100;                         // fast blink
  else if (gpsValid())    on = (now % 2000) < 80;                         // slow heartbeat
  else { unsigned long p = now % 1600; on = (p < 100) || (p >= 250 && p < 350); }   // double blink
  digitalWrite(PIN_LED, on ? HIGH : LOW);
}

void connectWifi(bool blocking) {
  if (wifiUp()) return;
  Serial.printf("[WiFi] connecting to %s ...\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  lastWifiTry = millis();
  if (!blocking) return;
  unsigned long t0 = millis();
  while (!wifiUp() && millis() - t0 < 20000) { updateLed(); delay(20); }
  if (wifiUp()) Serial.printf("[WiFi] connected, IP %s, RSSI %d dBm\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
  else Serial.println("[WiFi] not connected yet - will keep retrying");
}

const char* classify(float dyn) {                       // behavioural classification, NOT a medical diagnosis
  if (dyn < 0.6f) return "RESTING";
  if (dyn < 2.5f) return "WALKING";
  if (dyn < 6.0f) return "RUNNING";
  return "HIGH ACTIVITY";
}

void readImu() {
  mpu.update();
  ax = mpu.getAccX() * G_MS2; ay = mpu.getAccY() * G_MS2; az = mpu.getAccZ() * G_MS2;   // m/s^2
  gx = mpu.getGyroX(); gy = mpu.getGyroY(); gz = mpu.getGyroZ();                           // deg/s
  float mag = sqrtf(ax * ax + ay * ay + az * az);
  dynSum += fabsf(mag - G_MS2); dynCount++;
}

bool sendTelemetry() {
  float meanDyn = dynCount ? dynSum / dynCount : 0; dynSum = 0; dynCount = 0;
  const char* activity = classify(meanDyn);
  bool valid = gpsValid();
  String j; j.reserve(380);
  j += "{\"device_id\":\""; j += DEVICE_ID; j += "\",\"gps_valid\":"; j += valid ? "true" : "false";
  if (valid) { j += ",\"lat\":"; j += String(gps.location.lat(), 6); j += ",\"lon\":"; j += String(gps.location.lng(), 6); }
  else       { j += ",\"lat\":null,\"lon\":null"; }                      // never send fake GPS
  j += ",\"speed_kmh\":"; j += String(valid && gps.speed.isValid() ? gps.speed.kmph() : 0.0, 1);
  j += ",\"satellites\":"; j += String(gps.satellites.isValid() ? (int)gps.satellites.value() : 0);
  j += ",\"ax\":"; j += String(ax, 3); j += ",\"ay\":"; j += String(ay, 3); j += ",\"az\":"; j += String(az, 3);
  j += ",\"gx\":"; j += String(gx, 2); j += ",\"gy\":"; j += String(gy, 2); j += ",\"gz\":"; j += String(gz, 2);
  j += ",\"activity\":\""; j += activity; j += "\"}";

  for (uint8_t attempt = 1; attempt <= 3; attempt++) {          // HTTP retry
    if (!wifiUp()) return false;
    WiFiClient client; HTTPClient http;
    http.setTimeout(5000);
    http.begin(client, SERVER_URL);
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Device-Key", DEVICE_KEY);
    int code = http.POST(j);
    Serial.printf("[HTTP] try %u -> %d  %s\n", attempt, code, code > 0 ? http.getString().c_str() : HTTPClient::errorToString(code).c_str());
    http.end();
    if (code == 200 || code == 202) { flashShort(); return true; }
    if (code == 401) { Serial.println("[HTTP] 401 unauthorized: check DEVICE_ID / DEVICE_KEY / that the collar exists on the server"); }
    flashError();
    unsigned long t0 = millis(); while (millis() - t0 < 600) { updateLed(); delay(10); }
  }
  return false;
}

void setup() {
  Serial.begin(115200); delay(200);
  Serial.println("\n=== PAWSE collar firmware, device " + String(DEVICE_ID) + " ===");
  pinMode(PIN_LED, OUTPUT); digitalWrite(PIN_LED, LOW);
  gpsSerial.begin(9600);                                   // NEO-6M default baud
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.beginTransmission(0x68);
  imuOk = (Wire.endTransmission() == 0);
  if (imuOk) { mpu.begin(); Serial.println("[IMU] calibrating gyro - keep the collar still..."); mpu.calcGyroOffsets(false); Serial.println("[IMU] ready"); }
  else Serial.println("[IMU] MPU6050 NOT found at 0x68 - check SDA(D2)/SCL(D1)/3V3/GND. Continuing without IMU.");
  connectWifi(true);
}

void loop() {
  while (gpsSerial.available() > 0) { gps.encode(gpsSerial.read()); gpsCharsSeen++; }
  if (imuOk) readImu();
  if (!wifiUp() && millis() - lastWifiTry > 10000) connectWifi(false);        // WiFi retry every 10 s

  unsigned long now = millis();
  if (now - lastSend >= SEND_INTERVAL_MS) {
    lastSend = now;
    if (wifiUp()) sendTelemetry(); else Serial.println("[WiFi] down - skipping send");
  }
  if (now - lastDebug >= 2000) {
    lastDebug = now;
    Serial.printf("[DBG] wifi=%d gps=%s sats=%d lat=%.6f lon=%.6f spd=%.1f | a=(%.2f %.2f %.2f) NMEA chars=%lu\n", wifiUp(), gpsValid() ? "FIX" : "no-fix",
                  gps.satellites.isValid() ? (int)gps.satellites.value() : 0, gps.location.lat(), gps.location.lng(), gps.speed.kmph(), ax, ay, az, gpsCharsSeen);
    if (gpsCharsSeen < 10 && now > 6000) Serial.println("[GPS] no NMEA data - check NEO-6M wiring (TX->D5) and power; antenna needs open sky for a fix");
  }
  updateLed();
  delay(15);
}
