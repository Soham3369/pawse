# PAWSE ESP8266 firmware (device `sensi69`)

1. Arduino IDE -> File > Preferences > *Additional boards manager URLs*: `https://arduino.esp8266.com/stable/package_esp8266com_index.json`
2. Tools > Board > Boards Manager > install **esp8266** (Community). Select **NodeMCU 1.0 (ESP-12E Module)**.
3. Sketch > Include Library > Manage Libraries: install **TinyGPSPlus** (Mikal Hart) and **MPU6050_tockn** (tockn).
4. Edit the *USER SETTINGS* block: `WIFI_SSID`, `WIFI_PASS`, `SERVER_URL` (your PC's LAN IP), `DEVICE_KEY` (= `PAWSE_SENSI69_KEY`).
5. Upload speed 115200, open Serial Monitor at **115200**.

| Part | Pin | NodeMCU |
|---|---|---|
| MPU6050 VCC / GND | | 3V3 / GND |
| MPU6050 SDA | GPIO4 | D2 |
| MPU6050 SCL | GPIO5 | D1 |
| NEO-6M TX -> | GPIO14 | D5 |
| NEO-6M RX <- | GPIO12 | D6 |
| NEO-6M GND (VCC: see main README) | | GND (3V3) |
| LED via 220 Ω | GPIO13 | D7 |

LED: fast blink = no WiFi · slow heartbeat = WiFi + GPS fix · double blink = WiFi, GPS unavailable · short flash = sent · 3 rapid flashes = server error.
