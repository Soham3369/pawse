/* PAWSE dashboard: live map, charts, polling, GPS fallback, AI popup. Also drives Insights + Missing pages. */
(function () {
  const $ = id => document.getElementById(id);
  const ACTS = ['RESTING', 'WALKING', 'RUNNING', 'HIGH ACTIVITY'];
  const dogId = window.PAWSE_DOG;
  const charts = {};
  function mk(id, cfg) {                        // safe destroy / rebuild
    const el = $(id); if (!el) return null;
    if (charts[id]) charts[id].destroy();
    return (charts[id] = new Chart(el.getContext('2d'), cfg));
  }
  const tile = () => L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' });
  const icon = (emoji, dim) => L.divIcon({ className: '', html: `<div class="pawmark ${dim ? 'dim' : ''}">${emoji}</div>`, iconSize: [28, 28], iconAnchor: [14, 14] });
  const hhmmss = s => new Date(s).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  /* ================= INSIGHTS PAGE ================= */
  if (window.PAWSE_PAGE === 'insights') {
    fetch('/api/insights/' + dogId).then(r => r.json()).then(d => {
      $('i-dist').textContent = d.distance_km; $('i-n').textContent = d.samples; $('i-an').textContent = d.anomalies_7d;
      mk('mixChart', { type: 'doughnut', data: { labels: Object.keys(d.activity), datasets: [{ data: Object.values(d.activity), backgroundColor: ['#c4b5fd', '#5eead4', '#ffc83d', '#ff6fa5'] }] },
        options: { responsive: true, maintainAspectRatio: false } });
      mk('hourChart', { type: 'bar', data: { labels: [...Array(24).keys()].map(h => h + ':00'), datasets: [{ label: 'km/h', data: d.hourly_speed, backgroundColor: '#3b82f6', borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, title: { display: true, text: 'avg km/h' } } } } });
      $('zones').innerHTML = d.community.length ? d.community.map(z => `<li><b>${z.name}</b> · ~${z.lat}, ${z.lon} · ${z.pets} pets · peak ${z.peak}</li>`).join('') : '<li class="sub">Not enough community data yet.</li>';
    });
    return;
  }

  /* ================= MISSING PAGE ================= */
  if (window.PAWSE_PAGE === 'missing') {
    const map = L.map('map-missing').setView(window.PAWSE_HOME, 15); tile().addTo(map);
    let layer = L.layerGroup().addTo(map);
    $('go').onclick = async () => {
      const r = await fetch('/api/missing/' + dogId); const d = await r.json();
      if (!r.ok) { $('result').innerHTML = `<div class="flash error" style="grid-column:1/-1">${d.error}</div>`; return; }
      layer.clearLayers();
      L.marker([d.last_known.lat, d.last_known.lon], { icon: icon('📍') }).bindPopup('Last known GPS position').addTo(layer);
      L.polyline(d.history, { color: '#3b82f6', weight: 3 }).addTo(layer);
      L.circle([d.center.lat, d.center.lon], { radius: d.radius_m, color: '#ff6fa5', fillOpacity: .15 }).bindPopup('Estimated search area').addTo(layer);
      if (d.sector.length) L.polygon(d.sector, { color: '#ffc83d', weight: 2, fillOpacity: .12 }).addTo(layer);
      map.fitBounds(L.circle([d.center.lat, d.center.lon], { radius: d.radius_m * 1.4 }).getBounds());
      const k = (a, b) => `<div class="metric"><div class="k">${a}</div><div class="v" style="font-size:1.1rem">${b}</div></div>`;
      $('result').innerHTML = k('Estimated search area', 'radius ~' + d.radius_m + ' m') + k('Last known position', d.last_known.lat.toFixed(5) + ', ' + d.last_known.lon.toFixed(5)) +
        k('Recent direction', d.heading_deg === null ? 'unknown' : d.heading_deg + '° (bearing)') + k('Confidence', d.confidence_label + ' (' + d.confidence + ')') +
        k('Avg recent speed', d.avg_speed_kmh + ' km/h') + k('Since last fix', d.elapsed_min + ' min') +
        `<div class="sub" style="grid-column:1/-1">${d.note}${d.source_demo ? ' (Based on seeded/presentation telemetry.)' : ''}</div>`;
    };
    return;
  }

  /* ================= LIVE DASHBOARD ================= */
  const boot = window.PAWSE_BOOT; if (!boot) return;
  let latest = boot, deviceLoc = null, panned = false, devMarker = null, lastAlertId = Math.max(0, ...boot.alerts.map(a => a.id));
  const f = boot.geofence, c0 = f.lat != null ? [f.lat, f.lon] : [19.7063, 72.7836];
  const map = L.map('map').setView(boot.last_known && !boot.pinned ? [boot.last_known.lat, boot.last_known.lon] : c0, 16);
  tile().addTo(map);
  const petMarker = L.marker(c0, { icon: icon('🐾') }).addTo(map);
  const fence = L.circle(c0, { radius: Math.max(f.radius, 1), color: '#3b82f6', weight: 2, fillOpacity: f.radius ? .08 : 0, dashArray: f.radius ? null : '4 6' }).addTo(map);
  const trail = L.polyline([], { color: '#ff6fa5', weight: 4, opacity: .8 }).addTo(map);
  $('recenter').onclick = () => { const p = petMarker.getLatLng(); map.setView(latest.gps.live ? p : (deviceLoc && !latest.last_known ? deviceLoc : p), 17); };

  function toast(title, msg) {
    const t = document.createElement('div'); t.className = 'toast'; t.innerHTML = `<b>${title}</b>${msg}`;
    $('toasts').appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 450); }, 7000);
  }

  function renderMap(d) {
    const live = d.gps.live;
    if (live) {
      petMarker.setLatLng([d.gps.lat, d.gps.lon]).setIcon(icon('🐾'));
      if (!panned && !d.pinned) { map.setView([d.gps.lat, d.gps.lon], 17); panned = true; }
      if (devMarker) { map.removeLayer(devMarker); devMarker = null; }
      $('dev-badge').style.display = 'none';
      $('map-note').textContent = 'Marker = PET GPS (live collar fix).';
    } else {
      if (d.last_known) petMarker.setLatLng([d.last_known.lat, d.last_known.lon]).setIcon(icon('🐾', true)).bindTooltip('Last known PET GPS', { direction: 'top' });
      if (deviceLoc) {
        if (!devMarker) devMarker = L.marker(deviceLoc, { icon: icon('📍') }).bindTooltip('DEVICE LOCATION (owner device fallback)').addTo(map);
        else devMarker.setLatLng(deviceLoc);
        if (!panned && !d.pinned && !d.last_known) { map.setView(deviceLoc, 16); panned = true; }
        $('dev-badge').style.display = '';
      }
      $('map-note').textContent = 'Pet GPS unavailable. Faded paw = last known PET GPS; 📍 = your DEVICE location (fallback). They are never merged.';
    }
    $('gps-badge').className = 'pill ' + (live ? 'green' : 'red');
    $('gps-badge').textContent = live ? '🟢 PET GPS LIVE' : '🔴 PET GPS OFFLINE';
    trail.setLatLngs(live ? d.trail : []);
  }

  function renderCharts(series) {
    const labels = series.map(s => hhmmss(s.t));
    const sp = $('speedChart');
    if (!charts.speedChart) {
      mk('speedChart', { type: 'line', data: { labels, datasets: [
        { label: 'Speed (km/h)', data: series.map(s => s.speed), borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,.15)', fill: true, tension: .35, yAxisID: 'y', pointRadius: 0 },
        { label: 'Accel magnitude (m/s²)', data: series.map(s => s.mag), borderColor: '#ff6fa5', tension: .35, yAxisID: 'y1', pointRadius: 0 }] },
        options: { responsive: true, maintainAspectRatio: false, animation: { duration: 250 }, interaction: { mode: 'index', intersect: false },
          scales: { x: { ticks: { maxTicksLimit: 6, maxRotation: 0 }, title: { display: true, text: 'Time' } },
            y: { beginAtZero: true, title: { display: true, text: 'km/h' } }, y1: { position: 'right', grid: { drawOnChartArea: false }, title: { display: true, text: 'm/s²' } } },
          plugins: { legend: { position: 'bottom' } } } });
      mk('actChart', { type: 'line', data: { labels, datasets: [{ label: 'Activity', data: series.map(s => s.act), stepped: true, borderColor: '#ffc83d', backgroundColor: 'rgba(255,200,61,.25)', fill: true,
          pointRadius: series.map(s => s.anomaly ? 6 : 0), pointBackgroundColor: series.map(s => s.anomaly ? '#ef4444' : '#ffc83d') }] },
        options: { responsive: true, maintainAspectRatio: false, animation: { duration: 250 },
          scales: { x: { ticks: { maxTicksLimit: 6, maxRotation: 0 }, title: { display: true, text: 'Time' } },
            y: { min: -.2, max: 3.2, ticks: { stepSize: 1, callback: v => ACTS[v] || '' } } },
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ACTS[c.parsed.y] + (series[c.dataIndex].anomaly ? ' ⚠ anomaly' : '') } } } } });
      return;
    }
    const a = charts.speedChart, b = charts.actChart;
    a.data.labels = labels; a.data.datasets[0].data = series.map(s => s.speed); a.data.datasets[1].data = series.map(s => s.mag); a.update();
    b.data.labels = labels; b.data.datasets[0].data = series.map(s => s.act);
    b.data.datasets[0].pointRadius = series.map(s => s.anomaly ? 6 : 0); b.data.datasets[0].pointBackgroundColor = series.map(s => s.anomaly ? '#ef4444' : '#ffc83d'); b.update();
  }

  function render(d) {
    latest = d;
    const L0 = d.latest;
    $('m-collar').textContent = d.status_label; $('sim-note').textContent = d.sim_note;
    $('mini-text').textContent = (d.mode === 'offline' ? '🔴 ' : '🟢 ') + d.status_label;
    $('mini-dot').className = 'dot ' + (d.mode === 'demo' ? 'demo' : d.mode === 'real' ? 'on' : 'off');
    if (L0) {
      $('m-speed').textContent = L0.speed.toFixed(1); $('m-activity').textContent = L0.activity;
      $('m-sats').textContent = L0.satellites; $('m-gps').textContent = d.gps.live ? 'GPS fix' : 'no fix';
      $('m-ai').innerHTML = L0.anomaly ? '<span class="pill red">⚠ anomaly</span> ' + L0.score : '<span class="pill green">normal</span> ' + L0.score;
      $('m-last').textContent = d.age_s == null ? '-' : (d.age_s < 60 ? d.age_s + ' s ago' : Math.round(d.age_s / 60) + ' min ago');
    }
    $('m-lat').textContent = d.gps.live ? d.gps.lat.toFixed(6) : (d.last_known ? d.last_known.lat.toFixed(6) + ' (last)' : '-');
    $('m-lon').textContent = d.gps.live ? d.gps.lon.toFixed(6) : (d.last_known ? d.last_known.lon.toFixed(6) + ' (last)' : '-');
    $('m-dist').textContent = d.distance_km;
    const w = d.weather;
    $('weather').innerHTML = w.available ? `<b style="font-size:1.6rem">${w.temp}°C</b> · ${w.condition}<br>💧 ${w.humidity}% humidity · 💨 ${w.wind} km/h wind` : 'Weather unavailable (no internet).';
    $('alerts').innerHTML = d.alerts.slice().reverse().map(a => `<li>${a.kind === 'ANOMALY' ? '⚠️' : '🛡'} ${a.message}<br><small>${new Date(a.t).toLocaleString()}</small></li>`).join('') || '<li class="sub">No alerts</li>';
    $('fence-info').textContent = d.geofence.radius ? `Radius ${Math.round(d.geofence.radius)} m` : 'Radius 0 m - map pinned to the configured location; breach alerts disabled.';
    d.alerts.filter(a => a.id > lastAlertId && a.kind === 'ANOMALY').forEach(a => toast('⚠️ AI ANOMALY DETECTED', 'Unusual movement pattern detected.'));
    lastAlertId = Math.max(lastAlertId, ...d.alerts.map(a => a.id));
    renderMap(d); renderCharts(d.series);
  }

  async function poll() {
    try {
      const r = await fetch('/api/live/' + dogId, { cache: 'no-store' });
      if (r.status === 403) { location.href = '/login'; return; }
      render(await r.json());
    } catch (e) { $('mini-text').textContent = '🔴 Server unreachable'; $('mini-dot').className = 'dot off'; }
  }

  if ('geolocation' in navigator) {
    navigator.geolocation.watchPosition(p => {
      deviceLoc = [p.coords.latitude, p.coords.longitude];
      $('fl').value = deviceLoc[0]; $('fo').value = deviceLoc[1]; $('fence-here').disabled = false;
      renderMap(latest);
    }, err => { $('map-note').textContent = 'Device location unavailable: ' + err.message; }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 });
  }
  render(boot);
  setInterval(poll, 3000);
  setTimeout(() => map.invalidateSize(), 300);
})();
