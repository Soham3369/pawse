(function () {
  document.querySelectorAll('input[data-filter]').forEach(inp => inp.addEventListener('input', () => {
    const q = inp.value.toLowerCase();
    document.querySelectorAll(inp.dataset.filter + ' tbody tr').forEach(tr => tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none');
  }));
  document.querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click', () => { navigator.clipboard && navigator.clipboard.writeText(b.dataset.copy); b.textContent = 'copied ✓'; }));
  const ds = window.ADMIN_DAYS, cv = document.getElementById('anomChart');
  if (ds && cv) new Chart(cv.getContext('2d'), { type: 'bar', data: { labels: ds.map(d => d.d), datasets: [{ label: 'AI anomalies', data: ds.map(d => d.n), backgroundColor: '#ff6fa5', borderRadius: 8 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
  const routes = window.ADMIN_ROUTES, mapEl = document.getElementById('map-admin');
  if (routes && mapEl) {
    const map = L.map('map-admin').setView(routes.length ? [routes[0].lat, routes[0].lon] : [19.2, 72.85], 9);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
    const colors = ['#3b82f6', '#ff6fa5', '#ffc83d', '#5eead4', '#fb923c', '#c4b5fd', '#22c55e', '#ef4444'], grp = [];
    routes.forEach((r, i) => { const c = L.circle([r.lat, r.lon], { radius: r.radius_m, color: colors[i % 8], fillOpacity: .25 }).bindPopup(`<b>${r.name}</b><br>${r.pets} pets · peak ${r.peak}`).addTo(map); grp.push(c); });
    if (grp.length) map.fitBounds(L.featureGroup(grp).getBounds().pad(.3));
  }
})();
