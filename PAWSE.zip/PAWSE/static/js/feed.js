document.querySelectorAll('.like').forEach(btn => btn.addEventListener('click', async () => {
  const r = await fetch('/api/like/' + btn.dataset.id, { method: 'POST', headers: { 'X-CSRF': window.PAWSE.csrf } });
  if (!r.ok) return;
  const d = await r.json();
  btn.classList.toggle('on', d.liked);
  btn.innerHTML = (d.liked ? '❤️' : '🤍') + ' <span>' + d.count + '</span> likes';
}));
